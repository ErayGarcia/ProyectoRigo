﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unach.Equipo1.Datos;

namespace Unach.Equipo1.Logica
{
    public class UsuarioMetodo
    {

        public void GuardarUsuario(string nombre, string correo, string contraseña)
        {
            string connectionString = "Data Source=Pc-Garpi\\SQLEXPRESS;Initial Catalog=Defin;Integrated Security=True"; // Reemplaza esto con tu cadena de conexión real.

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Usuario (NombreUsuario, CorreoElectronico, Contraseña) VALUES (@NombreUsuario, @CorreoElectronico, @Contraseña)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@NombreUsuario", nombre);
                command.Parameters.AddWithValue("@CorreoElectronico", correo);
                command.Parameters.AddWithValue("@Contraseña", contraseña);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

    }
}
