﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Unach.Equipo1.Datos;

namespace Unach.Equipo1.Logica
{
    public class inicio
    {
        public bool VerificarCredenciales(string correo, string contraseña)
        {
            string connectionString = "Data Source=Pc-Garpi\\SQLEXPRESS;Initial Catalog=Defin;Integrated Security=True"; // Reemplaza esto con tu cadena de conexión real.
            string query = "SELECT COUNT(*) FROM Usuario WHERE CorreoElectronico = @Correo AND Contraseña = @Contraseña";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Correo", correo);
                command.Parameters.AddWithValue("@Contraseña", contraseña);

                connection.Open();
                int count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
    }
}
