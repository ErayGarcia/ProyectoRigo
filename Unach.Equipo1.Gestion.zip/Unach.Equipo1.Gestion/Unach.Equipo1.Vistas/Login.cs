﻿using Unach.Equipo1.Vistas.Sesion;

namespace Unach.Equipo1.Vistas
{
    internal class Login : login
    {
    }
}